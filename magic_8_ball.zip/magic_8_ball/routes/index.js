var express = require('express');
var router = express.Router();
var adverbs = ["expressly", "explicitly", "definitely"];

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', {adverbs: adverbs});
});

router.get('/about_me', function(req, res, next) {
  res.send("I'm studying JS")
});

// router.get('/magic', function(req, res, next) {
//   res.render('magic');
// });


module.exports = router;
