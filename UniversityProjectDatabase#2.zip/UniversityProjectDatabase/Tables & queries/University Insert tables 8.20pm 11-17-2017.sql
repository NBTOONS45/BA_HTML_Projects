/*****  Instructor   ******************************************************/
INSERT INTO Instructor VALUES('John',  	 'Beck', 	  '123 Maple Street',   '30117');
INSERT INTO Instructor VALUES('Jessica', 'Hammer',    '136 Maple Street',   '30117');
INSERT INTO Instructor VALUES('Ashley',  'Peacock',   '456 Maple Circle',   '30117');
INSERT INTO Instructor VALUES('Luis',    'Anderson',  '879 Maple Circle',   '30117');
INSERT INTO Instructor VALUES('David',	 'Smith',	  '943 Maple Circle',   '30117');


/*****  Course  ******************************************************/
INSERT INTO COURSE VALUES( 'English  1',          '25',  'On Campus', '08:00', '09:15');
INSERT INTO COURSE VALUES( 'Calculus 3',          '20',  'On Campus', '12:00', '13:15');
INSERT INTO COURSE VALUES( 'Biology 1',           '35',  'On Campus', '17:00', '19:00');
INSERT INTO COURSE VALUES( 'Computer Science 2',  '15',  'OnLINE',	  '13:45', '14:30');
INSERT INTO COURSE VALUES( 'Economics 1',         '40',  'OnLINE',    '15:00', '16:15');


/*****  Department_Assignment  ******************************************************/
INSERT INTO Department_Assignment VALUES (1,1);
INSERT INTO Department_Assignment VALUES (2,2);
INSERT INTO Department_Assignment VALUES (3,3);	
INSERT INTO Department_Assignment VALUES (4,4);
INSERT INTO Department_Assignment VALUES (5,5);


/*****  Student  ******************************************************/
INSERT INTO Student VALUES('Gabriel',	 'Riley', 	'1601 Maple Street', '30117');
INSERT INTO Student VALUES('Nicholas ',  'Hart',    '1601 Maple Street', '30117');
INSERT INTO Student VALUES('Jaime', 	 'Gordon',  '1601 Maple Street', '30117');
INSERT INTO Student VALUES('Tanner',	 'Foster',  '1601 Maple Street', '30117');
INSERT INTO Student VALUES('Ashton',	'Davidson', '1601 Maple Street', '30117');


/*****  REGISTRATION  ******************************************************/
INSERT INTO REGISTRATION VALUES(1,'08:04');
INSERT INTO REGISTRATION VALUES(2,'11:03'); 
INSERT INTO REGISTRATION VALUES(3,'13:45');
INSERT INTO REGISTRATION VALUES(4,'18:56');
INSERT INTO REGISTRATION VALUES(5,'16:46');


/***** Tuition_ Bill  ******************************************************/
INSERT INTO Tuition_Bill  VALUES(1, '$8,552.00', '1-Dec-17');
INSERT INTO Tuition_Bill  VALUES(2, '$9,632.00', '1-Dec-17'); 
INSERT INTO Tuition_Bill  VALUES(3, '$8,943.00', '1-Dec-17');
INSERT INTO Tuition_Bill  VALUES(4, '$9,564.00', '1-Dec-17');
INSERT INTO Tuition_Bill  VALUES(5, '$10,489.00','1-Dec-17');


/*****  Payment  ******************************************************/
INSERT INTO PAYMENT VALUES( '8,552.00', '20:00', 'CASH');
INSERT INTO PAYMENT VALUES( '9,632.00', '18:00', 'CREDIT');
INSERT INTO PAYMENT VALUES( '8,943.00', '17:51', 'CREDIT');
INSERT INTO PAYMENT VALUES( '9,564.00', '16:30', 'CREDIT');
INSERT INTO PAYMENT VALUES( '10,489.00','14:03', 'CASH');


/***** Bill_Paymentline   ******************************************************/
INSERT INTO BILL_PAYMENTLINE VALUES(1,1); 
INSERT INTO BILL_PAYMENTLINE VALUES(2,2);
INSERT INTO BILL_PAYMENTLINE VALUES(3,3); 
INSERT INTO BILL_PAYMENTLINE VALUES(4,4);
INSERT INTO BILL_PAYMENTLINE VALUES(5,5);










