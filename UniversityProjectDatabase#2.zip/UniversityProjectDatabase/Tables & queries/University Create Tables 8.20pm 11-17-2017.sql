CREATE TABLE Instructor(
    InstrucID       Integer      IDENTITY(1,1),
    FirstName       CHAR(25)     null,
    LastName        CHAR(25)     null,
    Address_        CHAR(25)     null,  
    Zip             NUMERIC      null,    
    CONSTRAINT  Instructor_PK PRIMARY KEY(InstrucID)
	 
    );

CREATE  TABLE Course (
    courseID      	Integer      IDENTITY(1,1), 
    Name       		Char(50)     null, 
    Seats  		    Integer      null,
    Location        Char(50)     null,
    StartingTime    datetime     null,  
    EndingTime		datetime     null,    
    CONSTRAINT  Course_PK PRIMARY KEY (courseID) 

    );

CREATE  TABLE Department_Assignment(
    InstrucID       Integer        not null,
	CourseID		Integer		   not null,
	CONSTRAINT PK_assign PRIMARY KEY (InstrucID,CourseID),
    CONSTRAINT      Instructor_FK  Foreign Key(InstrucID)
							 REFERENCES Instructor (InstrucID),
	CONSTRAINT      Course_FK      FOREIGN KEY(courseID)
							 REFERENCES course (courseID)
	);
		
CREATE  TABLE Student (
    StudentID       Integer    	  IDENTITY(1,1),  
    FirstName       Char(25)      null,  
    LastName        CHAR(25)      null,
	Address_        Char(50)	  null,
    Zip			    NUMERIC       null,    
    CONSTRAINT      student_PK    PRIMARY KEY (studentID)

	);


CREATE  TABLE Registration (
    StudentID			 Integer    	IDENTITY(1,1),
    CourseID			 Integer		not null,  
    TimeOfRegist 		 DateTime		null,
	CONSTRAINT Student_Course_Pk PRIMARY KEY (StudentID,CourseID),
    CONSTRAINT Student_Fk    	 FOREIGN KEY  (StudentID)
							 REFERENCES Student (StudentID),
    CONSTRAINT Course_Foregin    FOREIGN KEY (CourseID)
							 REFERENCES course (CourseID)
	);
						
CREATE  TABLE Tuition_Bill (
    TuitionID       Integer    	  IDENTITY(1,1),
    StudentID       Integer		  not null,  
    Amount          Money         null,  
    Day_year        date          null,
	CONSTRAINT      tuition_PK	 PRIMARY KEY (TuitionID),
    CONSTRAINT      Student_Foreign FOREIGN KEY (StudentID)
                        REFERENCES Student (StudentID)
	);
						
CREATE  TABLE Payment (
    PaymentID        		Integer    	  IDENTITY(1,1),
    Amount          		Money    	  null,  
    Time_            		time          null,  
    PaymentMethod         	CHAR(25)      null,
    CONSTRAINT   Payment_PK PRIMARY KEY (Paymentid)

	);

CREATE  TABLE Bill_PaymentLine (
    TuitionID	Integer    	  not null,
    PaymentID   Integer		  not null,  
	constraint  Payment_Foregin	  PRIMARY KEY (TuitionID,PaymentID),
    CONSTRAINT  Tuition_Foregin	  FOREIGN KEY (tuitionID)
                        REFERENCES Tuition_Bill (tuitionId),
    CONSTRAINT  Payment_Foregin_K FOREIGN KEY (PaymentID)
                        REFERENCES Payment (PaymentID)

	);